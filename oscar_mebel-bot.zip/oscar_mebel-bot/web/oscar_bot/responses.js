module.exports={
    welcome1:'Добро пожаловать на наш магазин ',
    welcome2:'\nВыберетье команду:',
    catalogue: 'Наш каталог',
    catalogue_with_inline_keyboard: 'Выберите один из каталогов:',
    sale_empty: '⚠️ Извините, на данный момент нет никаких акций 😔',
    sale: '🔔 Акция на OSCAR MEBEL',
    back_main_menu: 'Выберитье раздел:',
    sub_catalogue_msg: 'Выберите раздел чтобы вывести список товаров:',
    back_btn_sub_catalogue: '↖️ Вернуться в суб-каталог',
    information_btn_txt: 'Для информации',
    information_btn_url: 'https://t.me/Oscarofficefurniture_bot',
    empty_category: '⚠️ Извините, эта категория пока пуста!'
}