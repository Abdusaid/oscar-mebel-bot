module.exports={
    root:[
        [{text:'level1',callback_data:'01'}],
        [{text:'level2',callback_data:'02'}]
    ],

    sc1:[
        [{text:'sc1_level1',callback_data:'sc11'}],
        [{text:'sc2_level2_data',callback_data:'good'}]
    ],

//////////////////////////////////////////////////////////////////

    good:[
        {
            picture:'./sales/1.jpg',
            description:'test text'
        },
        {
            picture:'https://i2.wp.com/ibcomputing.com/wp-content/uploads/2018/02/Get_Public_Link_Bot_10_Useful_Telegram_Bots.jpg?fit=576%2C1024&ssl=1',
            description:'test text'
        }
    ]
}