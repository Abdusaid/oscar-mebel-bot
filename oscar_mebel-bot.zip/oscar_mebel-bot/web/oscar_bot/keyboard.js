const kb = require('./keyboard-buttons')
module.exports={
    main:[
        [kb.main.catalogues],
        [kb.main.sale,kb.main.about]
    ],
    exit:[
        [kb.exit.mcatalogue],
        [kb.exit.exit]
    ],
    exitabout:[
        [kb.exitabout.back]
    ]
}