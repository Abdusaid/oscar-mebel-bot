module.exports = {
    main:{
        catalogues:'📂 Наш каталог',
        sale:'🛍 Акция',
        about:'🛋 О нас'
        
    },
    exit:{
        mcatalogue:'🗂 В начало каталога',
        exit:'◀️ Назад в главны меню'
    },
    exitabout:{
        back:'◀️ Назад'
    }

}