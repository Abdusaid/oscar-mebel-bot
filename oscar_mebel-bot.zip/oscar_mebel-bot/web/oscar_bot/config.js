module.exports={
    TOKEN:'1185997109:AAFqTaqEhTobFjrR9_wYWA70gGvyBcDYfzI',
    about:`
<b>OSCAR Mebel</b>\n
📍 Наш адрес: ____
⏩ Оринтир:_____
☎️ Телефон:_____
📲 Телеграм: @____
`,
}